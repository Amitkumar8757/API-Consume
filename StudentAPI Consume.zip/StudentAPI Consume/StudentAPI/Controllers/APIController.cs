﻿using CRUDapi.Data;
using CRUDapi.Logic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {

        private readonly IStudent studentService;

        public APIController(IStudent employee)
        {
            studentService = employee;
        }
        [HttpGet]
        [Route("GetAllStudents")]
        public IActionResult GetAllStudents()
        {
            var results = studentService.GetStudents();
            if (results.Count > 0)
            {


                return Ok(results);
            }
            else
            {
                return NotFound("Student not found !");
            }

        }
        [HttpGet]
        [Route("GetStudentById/{id}")]
        public IActionResult GetStudentById(int id)
        {
            var results = studentService.GetStudentById(id);
            if (results != null)
            {


                return Ok(results);
            }
            else
            {
                return NotFound("Student not found !");
            }

        }

        [HttpPost]
        [Route("Create")]
        public IActionResult Create(Student stud)
        {
            var result = studentService.Create(stud);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return Ok();
            }

        }
        [HttpDelete]
        [Route("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            else
            {
                var result = studentService.Delete(id);

                if (result != null)
                {
                    return Ok(result);
                }

                return NotFound();
            }
        }
        
         [HttpPut]
         [Route("Update")]
        public IActionResult Update(Student stud)
        {
            if (stud == null)
            {
                return BadRequest();

            }
            else
            {
                var result = studentService.Update(stud);
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound();
                }
            }
        }
    }
}
