﻿using CRUDapi.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace StudentAPI.Controllers
{
    public class StudentController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<Student> Students = new List<Student>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44380/api/API/GetAllStudents"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    Students = JsonConvert.DeserializeObject<List<Student>>(apiResponse);
                }
            }
            return View(Students);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Student stud)
        {


            Student obj = new Student();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(stud), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PostAsync("https://localhost:44380/api/API/Create",content))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        obj = JsonConvert.DeserializeObject<Student>(apiResponse);
                    }
                    else
                        ViewBag.StatusCode = response.StatusCode;
                }
            }
            return RedirectToAction("Index");
        }




         [HttpGet]
        public async Task<IActionResult> Update(int id)
        {
            Student obj = new Student();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44380/api/API/GetStudentById/" + id))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        obj = JsonConvert.DeserializeObject<Student>(apiResponse);
                    }
                    else
                    {
                        ViewBag.StatusCode = response.StatusCode;
                    }
                }

            }
            return View(obj);
        }

        [HttpPost]
        public async Task<IActionResult> Update(Student stud)
        {
            Student obj = new Student();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(stud), Encoding.UTF8, "application/json");
                using (var response = await httpClient.PutAsync("https://localhost:44380/api/API/Update/", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    //ViewBag.Result = "Success";
                    obj = JsonConvert.DeserializeObject<Student>(apiResponse);
                }
            }
             return RedirectToAction("Index");
           //return View(obj);
        }
      
        public async Task<IActionResult> Delete(int id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("https://localhost:44380/api/API/Delete/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }
               
            }

           return RedirectToAction("Index");
        }
    }
}

    
  
    

