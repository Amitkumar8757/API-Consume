﻿using CRUDapi.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDapi.Logic
{
        public class StudentService : IStudent
        {
            private readonly OurDbContext dbContext;

            public StudentService(OurDbContext _dbContext)
            {
                dbContext = _dbContext;
            }

            public Student Create(Student Stud)
            {
                dbContext.Students.Add(Stud);
                dbContext.SaveChanges();
                return Stud;
            }

            public Student Delete(int id)
            {
                var Stud = dbContext.Students.SingleOrDefault(e => e.Id == id);
                if (Stud != null)
                {
                    dbContext.Students.Remove(Stud);
                    dbContext.SaveChanges();
                    return Stud;
                }
                else
                {
                    return null;
                }
            }

            public Student GetStudentById(int id)
            {
                var stud = dbContext.Students.SingleOrDefault(e => e.Id == id);
                return stud;
            }

            public List<Student> GetStudents()
            {
                return dbContext.Students.ToList();
            }

            public Student Update(Student Stud)
            {
                var s = dbContext.Students.SingleOrDefault(e => e.Id == Stud.Id);
                if (s != null)
                {
                    s.FirstName = Stud.FirstName;
                    s.LastName = Stud.LastName;
                    s.Email = Stud.Email;
                    s.Mobile = Stud.Mobile;
                    dbContext.Students.Update(s);
                    dbContext.SaveChanges();
                    return Stud;
                }
                return null;
            }
        }
    }

