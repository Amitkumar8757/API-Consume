﻿using CRUDapi.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDapi.Logic
{
   public  interface IStudent
    {
        List<Student> GetStudents();

        Student Create(Student Stud);
        Student GetStudentById(int id);

        Student Delete(int id);
        Student Update(Student Stud);

    }
}
